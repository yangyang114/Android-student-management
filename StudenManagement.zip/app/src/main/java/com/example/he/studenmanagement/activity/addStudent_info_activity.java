package com.example.he.studenmanagement.activity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.he.studenmanagement.R;
import com.example.he.studenmanagement.tools.myDatabaseHelper;

/**
 * 添加学生信息的界面,修改学生信息的界面
 * Created by he on 2016/10/1.
 */
public class addStudent_info_activity extends Activity {
    private EditText name;
    private EditText pr;
    private EditText id;
    private EditText password;
    private String oldID;
    private Button sure;
    private myDatabaseHelper dbHelper;
    Intent oldData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.add_student_info_layout);
        name = (EditText) findViewById(R.id.add_student_layout_name);
        pr = (EditText) findViewById(R.id.add_student_layout_sex);
        id = (EditText) findViewById(R.id.add_student_layout_id);
        password = (EditText) findViewById(R.id.add_student_layout_password);
        dbHelper = myDatabaseHelper.getInstance(this);
        oldData = getIntent();
        if (oldData.getStringExtra("haveData").equals("true")) {
            initInfo();
        }
        sure = (Button) findViewById(R.id.add_student_layout_sure);
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_ = id.getText().toString();
                String name_ = name.getText().toString();
                String pr_ = pr.getText().toString();
                String password_ = password.getText().toString();
                if (!TextUtils.isEmpty(id_) && !TextUtils.isEmpty(name_) && !TextUtils.isEmpty(pr_)) {
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        db.beginTransaction();
                        db.execSQL("delete from student where id=?", new String[]{oldID});
                        Cursor cursor = db.rawQuery("select * from student where id=?", new String[]{id_});
                        if (cursor.moveToNext()) {
                            Toast.makeText(addStudent_info_activity.this, "已有学生使用该学号,请重新输入", Toast.LENGTH_SHORT).show();
                        } else {
                            db.execSQL("insert into student(id,name,pr,password) values(?,?,?,?)", new String[]{id_, name_, pr_, password_, });
                            db.setTransactionSuccessful();
                            db.endTransaction();
                            Intent intent = new Intent(addStudent_info_activity.this, admin_activity.class);
                            startActivity(intent);
                        }
                } else {
                    Toast.makeText(addStudent_info_activity.this, "姓名，学号，性别均不能为空", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void initInfo() {
        String oldName = oldData.getStringExtra("name");
        name.setText(oldName);
        String oldpr = oldData.getStringExtra("pr");
        pr.setText(oldpr);
        String oldId = oldData.getStringExtra("id");
        oldID = oldId;
        id.setText(oldId);
        String oldNumber = oldData.getStringExtra("number");
        String oldPassword = oldData.getStringExtra("password");
        password.setText(oldPassword);
        int mathScore = oldData.getIntExtra("mathScore", 0);
        int chineseScore = oldData.getIntExtra("chineseScore", 0);
        int englishScore = oldData.getIntExtra("englishScore", 0);
    }
}
