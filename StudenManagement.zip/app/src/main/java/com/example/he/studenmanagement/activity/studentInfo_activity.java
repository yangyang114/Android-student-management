package com.example.he.studenmanagement.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.example.he.studenmanagement.R;
import com.example.he.studenmanagement.tools.Student;
import com.example.he.studenmanagement.tools.StudentAdapter;
import com.example.he.studenmanagement.tools.myDatabaseHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 展示学生信息的activity
 * Created by he on 2016/10/1.
 */
public class studentInfo_activity extends Activity {
    private List<Student> studentList = new ArrayList<Student>();
    private myDatabaseHelper dbHelper;
    private ListView listView;
    private StudentAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.studentinfo_activity_layout);
        dbHelper = myDatabaseHelper.getInstance(this);
        initStudent();
        adapter = new StudentAdapter(studentInfo_activity.this, R.layout.student_item, studentList);
        listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                final Student student = studentList.get(position);
                AlertDialog.Builder builder = new AlertDialog.Builder(studentInfo_activity.this);
                LayoutInflater factory = LayoutInflater.from(studentInfo_activity.this);
                final View textEntryView = factory.inflate(R.layout.stundent_info_layout, null);
                builder.setView(textEntryView);
                builder.setTitle("请选择相关操作");
                Button selectInfo = (Button) textEntryView.findViewById(R.id.student_info_select);
                selectInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder select_builder = new AlertDialog.Builder(studentInfo_activity.this);
                        select_builder.setTitle("学生详细信息");
                        StringBuilder sb = new StringBuilder();
                        sb.append("姓名：" + student.getName() + "\n");
                        sb.append("学号：" + student.getId() + "\n");
                        sb.append("省份：" + student.getPr() + "\n");
                        select_builder.setMessage(sb.toString());
                        select_builder.create().show();
                    }
                });
                Button delete_info = (Button) textEntryView.findViewById(R.id.student_info_delete);
                delete_info.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder delete_builder = new AlertDialog.Builder(studentInfo_activity.this);
                        delete_builder.setTitle("警告！！！！");
                        delete_builder.setMessage("您将删除该学生信息，此操作不可逆，请谨慎操作！");

                        delete_builder.setNegativeButton("取消", null);
                        delete_builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                SQLiteDatabase db = dbHelper.getWritableDatabase();
                                db.execSQL("delete from student where id=?", new String[]{student.getId()});
                                studentList.remove(position);
                                adapter.notifyDataSetChanged();

                            }
                        });
                        delete_builder.create().show();
                    }
                });
                Button update_info = (Button) textEntryView.findViewById(R.id.student_info_update);
                update_info.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(studentInfo_activity.this, addStudent_info_activity.class);
                        intent.putExtra("haveData", "true");
                        intent.putExtra("name", student.getName());
                        intent.putExtra("pr", student.getPr());
                        intent.putExtra("id", student.getId());
                        intent.putExtra("password", student.getPassword());
                        startActivity(intent);
                    }
                });
                builder.create().show();
            }
        });
    }
    private void initStudent() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from student order by id", null);
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndex("id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String password = cursor.getString(cursor.getColumnIndex("password"));
            String pr = cursor.getString(cursor.getColumnIndex("pr"));
            studentList.add(new Student(id,name,password, pr));
        }
        cursor.close();
    }
}
